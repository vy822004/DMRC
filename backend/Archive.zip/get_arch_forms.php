<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$host = "localhost";
$user = "root";
$password = "";
$database = "DMRC";
$port = 3308; // Change if needed

$conn = new mysqli($host, $user, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "DB connection failed"]);
    exit();
}

$sql = "SELECT * FROM Arcform";
$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Query failed: " . $conn->error]);
    exit();
}

$forms = [];
while ($row = $result->fetch_assoc()) {
    $forms[] = $row;
}

echo json_encode(["success" => true, "data" => $forms]);
$conn->close();
?>
