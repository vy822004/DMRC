<?php
// Debug logs for dev
file_put_contents("debug_post.txt", print_r($_POST, true));
file_put_contents("debug_files.txt", print_r($_FILES, true));

// Error reporting (keep off in prod)
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Headers for CORS and JSON
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Preflight handling
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// DB connection
$host = "localhost";
$port = 3308;
$user = "root";
$password = "";
$database = "DMRC";

$conn = new mysqli($host, $user, $password, $database, $port);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit();
}

// ✅ Get user ID from request
$userId = $_POST['user_id'] ?? '';

$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// File upload handler
function handleFileUpload($inputName, $label, $userId) {
    global $uploadDir;
    if (isset($_FILES[$inputName]) && $_FILES[$inputName]['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES[$inputName]['name'], PATHINFO_EXTENSION);
        $newFileName = $userId . "_" . $label . "." . $ext;
        $targetPath = $uploadDir . $newFileName;
        if (move_uploaded_file($_FILES[$inputName]['tmp_name'], $targetPath)) {
            return $newFileName; // Store just filename
        }
    }
    return '';
}

// Sanitize inputs
$incorporationDate = $_POST['incorporationDate'] ?? '';
$manufacturingYears = (int)($_POST['manufacturingYears'] ?? 0);
$materialOrigin = $_POST['materialOrigin'] ?? '';
$productionCapacity = $_POST['productionCapacity'] ?? '';
$lifespan = isset($_POST['lifespan']) && $_POST['lifespan'] !== '' ? (int)$_POST['lifespan'] : null;
$isCode = $_POST['isCode'] ?? '';
$isoCertified = isset($_POST['isoCertified']) ? 1 : 0;
$applicationArea = $_POST['applicationArea'] ?? '';
$usedInDMRC = isset($_POST['usedInDMRC']) ? 1 : 0;

// File uploads
$isCodeFile = handleFileUpload('isCodeFile', 'ISCODE', $userId);
$isoFile = handleFileUpload('isoFile', 'ISO', $userId);
$dmrcProofFile = handleFileUpload('dmrcProof', 'DMRC', $userId);

// ✅ Insert user_id too
$sql = "INSERT INTO Arcform (
    incorporation_date, manufacturing_years, material_origin,
    production_capacity, lifespan, is_code, is_code_file,
    iso_certified, iso_file, application_area, used_in_dmrc,
    dmrc_proof_file, UserId
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "SQL prepare failed",
        "error" => $conn->error
    ]);
    exit();
}

$stmt->bind_param(
    "sississsisisi",
    $incorporationDate,
    $manufacturingYears,
    $materialOrigin,
    $productionCapacity,
    $lifespan,
    $isCode,
    $isCodeFile,
    $isoCertified,
    $isoFile,
    $applicationArea,
    $usedInDMRC,
    $dmrcProofFile,
    $userId
);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Form submitted successfully"]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Database insert failed",
        "error" => $stmt->error
    ]);
}

$stmt->close();
$conn->close();
